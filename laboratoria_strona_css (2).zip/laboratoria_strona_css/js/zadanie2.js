"use strict";

function pokazKolekcje() {
    const imagesDiv = document.getElementById("images-count");
    const linksDiv = document.getElementById("links-count");
    const formsDiv = document.getElementById("forms-count");

    if (!imagesDiv || !linksDiv || !formsDiv) {
        return;
    }

    let wynik = "";

    wynik += "<strong>Kolekcja images:</strong><br>";
    wynik += "Liczba obrazów: " + document.images.length + "<br>";

    if (document.images.length > 0) {
        wynik += "Pierwszy obraz : " + (document.images.item(0).alt || "brak alt") + "<br>";

        if (document.images.item(1)) {
            wynik += "Drugi obraz : " + document.images.item(1).alt + "<br>";
        } else {
            wynik += "Drugi obraz: brak<br>";
        }
    }

    wynik += "<br>";

    wynik += "<strong>Kolekcja links:</strong><br>";
    wynik += "Liczba linków: " + document.links.length + "<br>";

    if (document.links.length > 0) {
        wynik += "Pierwszy link: " + document.links.item(0).textContent.substring(0, 30) + "...<br>";
    }

    wynik += "<br>";

    wynik += "<strong>Kolekcja forms:</strong><br>";
    wynik += "Liczba formularzy: " + document.forms.length + "<br>";

    if (document.forms.length > 0) {
        wynik += "Pierwszy formularz: " + (document.forms.item(0).id || "brak id") + "<br>";

        if (document.forms.namedItem("contact-form")) {
            wynik += "Formularz po nazwie : znaleziono<br>";
        }
    }

    wynik += "<br>";

    wynik += "<strong>Kolekcja anchors:</strong><br>";
    wynik += "Liczba kotwic: " + document.anchors.length + "<br>";

    if (document.anchors.length > 0) {
        wynik += "Pierwsza kotwica: " + document.anchors.item(0).name + "<br>";
    }

    imagesDiv.innerHTML = wynik;
    linksDiv.innerHTML = "";
    formsDiv.innerHTML = "";
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", pokazKolekcje);
} else {
    pokazKolekcje();
}