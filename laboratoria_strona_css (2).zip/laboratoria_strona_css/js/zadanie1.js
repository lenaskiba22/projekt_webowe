// "use strict";
//
// const lista = document.getElementById('lista-elementow');
//
// for(let i = 1; i <= 3; i++){
//     const li = document.createElement('li');
//     const tekst = document.createTextNode(Element ${i});
//     li.appendChild(tekst);
//     lista.appendChild(li);
// }
//
"use strict";

function wypelnijListe() {
    const lista = document.getElementById("lista-elementow");

    if (!lista) {
        return;
    }

    lista.innerHTML = "";


    const el1 = document.createElement("li");
    const txt1 = document.createTextNode("Element 1");
    el1.appendChild(txt1);
    el1.style.color = "#2563eb";
    lista.appendChild(el1);


    const el2 = document.createElement("li");
    const txt2 = document.createTextNode("Element 2");
    el2.appendChild(txt2);
    el2.style.color = "#16a34a";
    lista.appendChild(el2);


    const el3 = document.createElement("li");
    const txt3 = document.createTextNode("Element 3");
    el3.appendChild(txt3);
    el3.style.color = "#dc2626";
    lista.appendChild(el3);

    const elNowy = document.createElement("li");
    const txtNowy = document.createTextNode("Element wstawiony przed Element 2 (insertBefore)");
    elNowy.appendChild(txtNowy);
    elNowy.style.color = "#9333ea";
    lista.insertBefore(elNowy, el2);


    const elZast = document.createElement("li");
    const txtZast = document.createTextNode("Element zastąpił Element 3 (replaceChild)");
    elZast.appendChild(txtZast);
    elZast.style.color = "#ea580c";
    lista.replaceChild(elZast, el3);


    const el4 = document.createElement("li");
    const txt4 = document.createTextNode("Element 4 (rodzic: " + lista.tagName + ")");
    el4.appendChild(txt4);
    el4.style.color = "#0891b2";
    lista.appendChild(el4);


    const el5 = document.createElement("li");
    el5.id = "element-usun";
    const txt5 = document.createTextNode("Element 5 - kliknij przycisk aby usunąć");
    el5.appendChild(txt5);
    el5.style.color = "#e11d48";
    lista.appendChild(el5);

    const btn = document.createElement("button");
    const txtBtn = document.createTextNode("Usuń Element 5");
    btn.appendChild(txtBtn);
    btn.className = "btn btn-orange";
    btn.style.marginTop = "10px";

    btn.onclick = function() {
        const elDoUsun = document.getElementById("element-usun");
        if (elDoUsun && elDoUsun.parentNode) {
            elDoUsun.parentNode.removeChild(elDoUsun);
            btn.disabled = true;
            btn.textContent = "Usunięto!";
        }
    };

    lista.parentNode.insertBefore(btn, lista.nextSibling);
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", wypelnijListe);
} else {
    wypelnijListe();
}