package com.example.products.model;

public class Product {
    private Long id;
    private String name;
    private double weight;
    private double price;
    private int index;
    private String category;

    public Product() { }

    public Product(Long id, String name, double weight, double price, int index, String category) {
        this.id = id;
        this.name = name;
        this.weight = weight;
        this.price = price;
        this.index = index;
        this.category = category;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public double getWeight() { return weight; }
    public void setWeight(double weight) { this.weight = weight; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public int getIndex() { return index; }
    public void setIndex(int index) { this.index = index; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
}
