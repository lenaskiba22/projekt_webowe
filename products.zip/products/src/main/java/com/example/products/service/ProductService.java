package com.example.products.service;


import com.example.products.model.Product;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProductService {

    private List<Product> products = new ArrayList<>();
    private long nextId = 1;

    public ProductService() {
        // przykładowe dane
        add(new Product(null, "Chleb", 1.0, 5.20, 1, "Pieczywo"));
        add(new Product(null, "Masło", 0.25, 7.00, 2, "Nabiał"));
    }

    public List<Product> getAll() {
        return products;
    }

    public Product getById(Long id) {
        return products.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public void add(Product p) {
        p.setId(nextId++);
        products.add(p);
    }

    public void update(Product updated) {
        products.forEach(p -> {
            if (p.getId().equals(updated.getId())) {
                p.setName(updated.getName());
                p.setWeight(updated.getWeight());
                p.setPrice(updated.getPrice());
                p.setIndex(updated.getIndex());
                p.setCategory(updated.getCategory());
            }
        });
    }

    public void delete(Long id) {
        products.removeIf(p -> p.getId().equals(id));
    }
}