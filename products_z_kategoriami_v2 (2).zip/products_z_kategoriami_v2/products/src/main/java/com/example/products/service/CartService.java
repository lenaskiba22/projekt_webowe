package com.example.products.service;

import com.example.products.model.CartItem;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Service;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@Service
public class CartService {

    // ObjectMapper to główny obiekt Jacksona do konwersji
    private final ObjectMapper objectMapper = new ObjectMapper();
    private static final String COOKIE_NAME = "cart_items";

    public List<CartItem> getCartFromCookies(String cookieValue) {
        if (cookieValue == null || cookieValue.isEmpty()) {
            return new ArrayList<>();
        }
        try {
            // Dekodujemy URL (bo w ciastkach nie może być spacji i znaków specjalnych)
            String decoded = URLDecoder.decode(cookieValue, StandardCharsets.UTF_8);

            // TypeReference pozwala Jacksonowi wiedzieć, że ma stworzyć Listę obiektów CartItem
            return objectMapper.readValue(decoded, new TypeReference<List<CartItem>>() {});
        } catch (JsonProcessingException e) {
            // Jeśli JSON w ciastku jest uszkodzony, zwracamy pustą listę
            return new ArrayList<>();
        }
    }

    public void saveCartToCookie(List<CartItem> cart, HttpServletResponse response) {
        try {
            // Zamiana listy obiektów na tekst JSON
            String json = objectMapper.writeValueAsString(cart);

            // Kodowanie, aby tekst był bezpieczny dla protokołu HTTP
            String encoded = URLEncoder.encode(json, StandardCharsets.UTF_8);

            Cookie cookie = new Cookie(COOKIE_NAME, encoded);
            cookie.setPath("/");
            cookie.setHttpOnly(true); // Bezpieczeństwo: ciastko niedostępne dla JS
            cookie.setMaxAge(7 * 24 * 60 * 60); // 7 dni
            response.addCookie(cookie);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }
}