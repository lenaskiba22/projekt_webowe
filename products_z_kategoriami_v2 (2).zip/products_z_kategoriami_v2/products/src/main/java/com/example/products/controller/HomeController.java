package com.example.products.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String index(HttpServletRequest request) {
        // Jeśli zalogowany to ADMIN, idzie do zarządzania produktami
        if (request.isUserInRole("ROLE_ADMIN")) {
            return "redirect:/products";
        }
        // W przeciwnym razie idzie do sklepu
        return "redirect:/shop";
    }
}