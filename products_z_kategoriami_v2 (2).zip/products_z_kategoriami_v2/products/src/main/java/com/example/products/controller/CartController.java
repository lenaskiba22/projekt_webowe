package com.example.products.controller;

import com.example.products.model.CartItem;
import com.example.products.model.Product;
import com.example.products.service.CartService;
import com.example.products.service.ProductService;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class CartController {
    private final ProductService productService;
    private final CartService cartService;

    public CartController(ProductService productService, CartService cartService) {
        this.productService = productService;
        this.cartService = cartService;
    }

    @GetMapping("/shop")
    public String shop(Model model) {
        model.addAttribute("products", productService.getAll());
        return "shop/index";
    }

    @PostMapping("/cart/add/{id}")
    public String addToCart(@PathVariable Long id,
                            @CookieValue(value = "cart_items", required = false) String cartCookie,
                            HttpServletResponse response) {
        List<CartItem> cart = cartService.getCartFromCookies(cartCookie);
        Product product = productService.getById(id);

        if (product != null) {
            boolean found = false;
            for (CartItem item : cart) {
                if (item.getProductId().equals(id)) {
                    item.setQuantity(item.getQuantity() + 1);
                    found = true;
                    break;
                }
            }
            if (!found) {
                cart.add(new CartItem(product.getId(), product.getName(), product.getPrice(), 1));
            }
            cartService.saveCartToCookie(cart, response);
        }
        return "redirect:/shop";
    }

    @GetMapping("/cart")
    public String viewCart(@CookieValue(value = "cart_items", required = false) String cartCookie, Model model) {
        List<CartItem> cart = cartService.getCartFromCookies(cartCookie);
        double total = cart.stream().mapToDouble(i -> i.getPrice() * i.getQuantity()).sum();
        model.addAttribute("cart", cart);
        model.addAttribute("total", total);
        return "shop/cart";
    }

    @PostMapping("/cart/update")
    public String updateQuantity(@RequestParam Long id, @RequestParam int delta,
                                 @CookieValue(value = "cart_items", required = false) String cartCookie,
                                 HttpServletResponse response) {
        List<CartItem> cart = cartService.getCartFromCookies(cartCookie);

        cart.removeIf(item -> {
            if (item.getProductId().equals(id)) {
                item.setQuantity(item.getQuantity() + delta);
                return item.getQuantity() <= 0;
            }
            return false;
        });

        cartService.saveCartToCookie(cart, response);
        return "redirect:/cart";
    }

    @PostMapping("/cart/remove/{id}")
    public String removeFromCart(@PathVariable Long id,
                                 @CookieValue(value = "cart_items", required = false) String cartCookie,
                                 HttpServletResponse response) {
        List<CartItem> cart = cartService.getCartFromCookies(cartCookie);
        cart.removeIf(item -> item.getProductId().equals(id));
        cartService.saveCartToCookie(cart, response);
        return "redirect:/cart";
    }
}