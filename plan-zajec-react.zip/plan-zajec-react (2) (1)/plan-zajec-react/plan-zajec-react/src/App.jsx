import { useState } from 'react'

function App() {
  const [subjects, setSubjects] = useState([
    { id: 1, name: 'Analiza Matematyczna C', duration: 90 },
    { id: 2, name: 'Język Angielski C1 C', duration: 180 },
    { id: 3, name: 'Podstawy implementacji systemów webowych L', duration: 90 },
    { id: 4, name: 'Podstawy informatyki przemysłowej L', duration: 90 },
    { id: 5, name: 'Sztuczna inteligencja L', duration: 90 }
  ]);

  const [newSubject, setNewSubject] = useState({ name: '', duration: '' });

  const addSubject = () => {
    if (newSubject.name.trim() && newSubject.duration) {
      setSubjects([
        ...subjects,
        {
          id: Date.now(),
          name: newSubject.name.trim(),
          duration: parseInt(newSubject.duration)
        }
      ]);
      setNewSubject({ name: '', duration: '' });
    }
  };

  const deleteSubject = (id) => {
    setSubjects(subjects.filter(subject => subject.id !== id));
  };

  const saveToJSON = () => {
    const data = {
      date: new Date().toLocaleDateString('pl-PL'),
      subjects: subjects,
      totalDuration: subjects.reduce((sum, s) => sum + s.duration, 0),
      totalSubjects: subjects.length
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `plan-zajec-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const totalDuration = subjects.reduce((sum, subject) => sum + subject.duration, 0);
  const totalHours = Math.floor(totalDuration / 60);
  const totalMinutes = totalDuration % 60;

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      addSubject();
    }
  };

  return (
      <div className="container">
        <h1>Plan Zajęć</h1>

        <div className="stats">
          <div className="stat-item">
            <div className="stat-value">{subjects.length}</div>
            <div className="stat-label">Przedmiotów</div>
          </div>
          <div className="stat-item">
            <div className="stat-value">
              {totalHours}h {totalMinutes}m
            </div>
            <div className="stat-label">Łączny czas</div>
          </div>
        </div>

        <div className="form-section">
          <h2>Dodaj nowy przedmiot</h2>
          <div className="form-group">
            <div className="input-wrapper">
              <label>Nazwa przedmiotu</label>
              <input
                  type="text"
                  placeholder="np. Algebra liniowa"
                  value={newSubject.name}
                  onChange={(e) => setNewSubject({ ...newSubject, name: e.target.value })}
                  onKeyPress={handleKeyPress}
              />
            </div>
            <div className="input-wrapper duration-input">
              <label>Czas trwania (min)</label>
              <input
                  type="number"
                  placeholder="90"
                  value={newSubject.duration}
                  onChange={(e) => setNewSubject({ ...newSubject, duration: e.target.value })}
                  onKeyPress={handleKeyPress}
              />
            </div>
            <button className="btn-add" onClick={addSubject}>
              Dodaj przedmiot
            </button>
          </div>
        </div>

        <div className="subjects-list">
          {subjects.length === 0 ? (
              <div className="empty-state">
                <h3>Brak przedmiotów</h3>
                <p>Dodaj pierwszy przedmiot, aby rozpocząć</p>
              </div>
          ) : (
              subjects.map((subject) => (
                  <div key={subject.id} className="subject-item">
                    <div className="subject-info">
                      <div className="subject-name">{subject.name}</div>
                      <div className="subject-duration">
                        {subject.duration} minut ({Math.floor(subject.duration / 60)}h {subject.duration % 60}m)
                      </div>
                    </div>
                    <button
                        className="btn-delete"
                        onClick={() => deleteSubject(subject.id)}
                    >
                      Usuń
                    </button>
                  </div>
              ))
          )}
        </div>

        {subjects.length > 0 && (
            <button className="btn-save" onClick={saveToJSON}>
              Zapisz plan do pliku JSON
            </button>
        )}
      </div>
  );
}

export default App