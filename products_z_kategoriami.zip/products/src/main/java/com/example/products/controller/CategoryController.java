package com.example.products.controller;

import com.example.products.model.Category;
import com.example.products.service.CategoryService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/categories")
public class CategoryController {

    private final CategoryService categoryService;

    public CategoryController(CategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("categories", categoryService.getAll());
        return "categories/list";
    }

    @GetMapping("/add")
    public String addForm(Model model) {
        model.addAttribute("category", new Category());
        return "categories/add";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute Category category) {
        categoryService.add(category);
        return "redirect:/categories";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        Category cat = categoryService.getById(id);
        if (cat == null) {
            // jeśli nie ma kategorii o takim id, przekieruj na listę z parametrem error
            return "redirect:/categories?notfound";
        }
        model.addAttribute("category", cat);
        return "categories/edit";
    }

    @PostMapping("/edit")
    public String edit(@ModelAttribute Category category) {
        categoryService.update(category);
        return "redirect:/categories";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        categoryService.delete(id);
        return "redirect:/categories";
    }
}
