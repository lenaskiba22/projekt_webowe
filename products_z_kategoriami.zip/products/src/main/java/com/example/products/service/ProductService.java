package com.example.products.service;

import com.example.products.model.Product;
import com.example.products.repo.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    private final ProductRepository repo;

    public ProductService(ProductRepository repo) {
        this.repo = repo;
    }

    public List<Product> getAll() {
        return repo.findAll();
    }

    public Product getById(Long id) {
        return repo.findById(id).orElse(null);
    }

    public void add(Product product) {
        repo.save(product);
    }

    public void update(Product product) {
        repo.save(product);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }
}
