package com.example.products.service;

import com.example.products.model.Category;
import com.example.products.repo.CategoryRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService {

    private final CategoryRepository repo;

    public CategoryService(CategoryRepository repo) {
        this.repo = repo;
    }

    public List<Category> getAll() {
        return repo.findAll();
    }

    public Category getById(Long id) {
        return repo.findById(id).orElse(null);
    }

    public void add(Category category) {
        repo.save(category);
    }

    public void update(Category category) {
        repo.save(category);
    }

    public void delete(Long id) {
        // Pobierz zarządzalną encję i usuń ją — dzięki cascade + orphanRemoval produkty zostaną usunięte
        Category category = repo.findById(id).orElse(null);
        if (category != null) {
            repo.delete(category);
        }
    }
}
