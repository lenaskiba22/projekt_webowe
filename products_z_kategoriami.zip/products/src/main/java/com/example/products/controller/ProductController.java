package com.example.products.controller;

import com.example.products.model.Category;
import com.example.products.model.Product;
import com.example.products.service.CategoryService;
import com.example.products.service.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/products")
public class ProductController {

    private final ProductService productService;
    private final CategoryService categoryService;

    public ProductController(ProductService productService, CategoryService categoryService) {
        this.productService = productService;
        this.categoryService = categoryService;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("products", productService.getAll());
        return "products/list";
    }

    @GetMapping("/add")
    public String addForm(Model model) {
        model.addAttribute("product", new Product());
        model.addAttribute("categories", categoryService.getAll());
        return "products/add";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute Product product) {
        if (product.getCategory() != null && product.getCategory().getId() != null) {
            Category cat = categoryService.getById(product.getCategory().getId());
            product.setCategory(cat);
        } else {
            product.setCategory(null);
        }
        productService.add(product);
        return "redirect:/products";
    }

    @GetMapping("/{id}")
    public String details(@PathVariable Long id, Model model) {
        Product product = productService.getById(id);
        if (product == null) {
            return "redirect:/products?notfound";
        }
        model.addAttribute("product", product);
        return "products/details";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        Product product = productService.getById(id);
        if (product == null) {
            return "redirect:/products?notfound";
        }
        model.addAttribute("product", product);
        model.addAttribute("categories", categoryService.getAll());
        return "products/edit";
    }

    @PostMapping("/edit")
    public String edit(@ModelAttribute Product product) {
        if (product.getCategory() != null && product.getCategory().getId() != null) {
            Category cat = categoryService.getById(product.getCategory().getId());
            product.setCategory(cat);
        } else {
            product.setCategory(null);
        }
        productService.update(product);
        return "redirect:/products";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        productService.delete(id);
        return "redirect:/products";
    }
}
