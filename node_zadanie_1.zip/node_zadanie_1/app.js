const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('views'));

// MySQL (Docker)
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'node_db',
    port: 3307
});

db.connect(err => {
    if (err) {
        console.error('Błąd połączenia z MySQL:', err);
        return;
    }
    console.log('Połączono z MySQL (Docker)');
});

// formularz
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

// submit
app.post('/submit', (req, res) => {
    const { name, email, age, gender } = req.body;

    // zapis do MySQL
    const sql = 'INSERT INTO users (name, email, age, gender) VALUES (?, ?, ?, ?)';
    db.query(sql, [name, email, age, gender], (err) => {
        if (err) {
            console.error(err);
            return res.send('Błąd zapisu do bazy');
        }

        // zapis do JSON
        const data = { name, email, age, gender };
        let jsonData = [];

        if (fs.existsSync('data.json')) {
            jsonData = JSON.parse(fs.readFileSync('data.json'));
        }

        jsonData.push(data);
        fs.writeFileSync('data.json', JSON.stringify(jsonData, null, 2));

        res.redirect('/');
    });
});

// tabela
app.get('/data', (req, res) => {
    db.query('SELECT * FROM users', (err, results) => {
        if (err) return res.send(err);

        let html = `
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Imię</th>
                <th>Email</th>
                <th>Wiek</th>
                <th>Płeć</th>
            </tr>`;

        results.forEach(r => {
            html += `
            <tr>
                <td>${r.id}</td>
                <td>${r.name}</td>
                <td>${r.email}</td>
                <td>${r.age}</td>
                <td>${r.gender}</td>
            </tr>`;
        });

        html += `</table><br><a href="/">Powrót</a>`;
        res.send(html);
    });
});

app.listen(PORT, () => {
    console.log(`Serwer działa: http://localhost:${PORT}`);
});
