package com.example.products.controller;

import com.example.products.model.Product;
import com.example.products.service.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/products")
public class ProductController {

    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    //lista produktów
    @GetMapping
    public String list(Model model) {
        model.addAttribute("products", service.getAll());
        return "products/list";
    }

    // dodawanie do form
    @GetMapping("/add")
    public String addForm(Model model) {
        model.addAttribute("product", new Product());
        return "products/add";
    }

    // dodawnaie zapis
    @PostMapping("/add")
    public String add(@ModelAttribute Product product) {
        service.add(product);
        return "redirect:/products";
    }

    @GetMapping("/{id}")
    public String details(@PathVariable Long id, Model model) {
        model.addAttribute("product", service.getById(id));
        return "products/details";
    }

    // edycja form
    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        model.addAttribute("product", service.getById(id));
        return "products/edit";
    }

    // edycja zapis
    @PostMapping("/edit")
    public String edit(@ModelAttribute Product product) {
        service.update(product);
        return "redirect:/products";
    }

    // usuwanie
    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        service.delete(id);
        return "redirect:/products";
    }
}
