"use strict";

function pokazKolekcje() {
    const imagesDiv = document.getElementById("images-count");
    const linksDiv = document.getElementById("links-count");
    const formsDiv = document.getElementById("forms-count");

    if (!imagesDiv || !linksDiv || !formsDiv) {
        return;
    }

    // === KOLEKCJA IMAGES ===
    let wynikImages = "<strong>Kolekcja images:</strong><br>";
    wynikImages += "Liczba obrazów: " + document.images.length + "<br>";

    if (document.images.length > 0) {
        wynikImages += "Pierwszy obraz: " + (document.images.item(0).alt || "brak alt") + "<br>";

        if (document.images.item(1)) {
            wynikImages += "Drugi obraz: " + document.images.item(1).alt + "<br>";
        } else {
            wynikImages += "Drugi obraz: brak<br>";
        }
    }

    // === KOLEKCJA LINKS ===
    let wynikLinks = "<strong>Kolekcja links:</strong><br>";
    wynikLinks += "Liczba linków: " + document.links.length + "<br>";

    if (document.links.length > 0) {
        const pierwszyLink = document.links.item(0);
        const tekstLinku = pierwszyLink.textContent.trim().substring(0, 30);
        wynikLinks += "Pierwszy link: " + tekstLinku + "...<br>";

        if (document.links.length > 1) {
            const drugiLink = document.links.item(1);
            const tekstDrugi = drugiLink.textContent.trim().substring(0, 30);
            wynikLinks += "Drugi link: " + tekstDrugi + "...<br>";
        }
    }

    // === KOLEKCJA FORMS ===
    let wynikForms = "<strong>Kolekcja forms:</strong><br>";
    wynikForms += "Liczba formularzy: " + document.forms.length + "<br>";

    if (document.forms.length > 0) {
        wynikForms += "Pierwszy formularz: " + (document.forms.item(0).id || "brak id") + "<br>";

        // Sprawdź namedItem
        const contactForm = document.forms.namedItem("contact-form");
        if (contactForm) {
            wynikForms += "Formularz contact-form (namedItem): znaleziono<br>";
        } else {
            wynikForms += "Formularz contact-form (namedItem): nie znaleziono<br>";
        }
    } else {
        wynikForms += "<em>Brak formularzy na tej stronie</em><br>";
    }

    // === KOLEKCJA ANCHORS ===
    wynikForms += "<br><strong>Kolekcja anchors:</strong><br>";
    wynikForms += "Liczba kotwic: " + document.anchors.length + "<br>";

    if (document.anchors.length > 0) {
        wynikForms += "Pierwsza kotwica (item(0)): name=\"" + document.anchors.item(0).name + "\"<br>";
    } else {
        wynikForms += "<em>Brak kotwic z atrybutem 'name'</em><br>";

        // Pokaż kotwice z ID
        const kotwiceZId = document.querySelectorAll('a[id], span[id]');
        wynikForms += "Elementy z ID jako kotwice: " + kotwiceZId.length + "<br>";
        if (kotwiceZId.length > 0) {
            wynikForms += "Pierwszy element z ID: id=\"" + kotwiceZId[0].id + "\"<br>";
        }
    }

    // Wypełnij odpowiednie divy
    imagesDiv.innerHTML = wynikImages;
    linksDiv.innerHTML = wynikLinks;
    formsDiv.innerHTML = wynikForms;
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", pokazKolekcje);
} else {
    pokazKolekcje();
}