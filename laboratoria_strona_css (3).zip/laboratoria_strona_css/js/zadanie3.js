"use strict";

window.addEventListener("DOMContentLoaded", () => {
    document.body.style.backgroundColor = "#FFFFFF";
    document.getElementById('bg-color').value = "#FFFFFF";
});

document.getElementById('bg-color').addEventListener('input', function() {
    document.body.style.backgroundColor = this.value;
});

document.getElementById('text-color').addEventListener('input', function() {
    document.body.style.color = this.value;
});

document.getElementById('font-family').addEventListener('change', function() {
    document.body.style.fontFamily = this.value;
});

