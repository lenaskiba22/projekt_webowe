// "use strict";
//
// const lista = document.getElementById('lista-elementow');
//
// for(let i = 1; i <= 3; i++){
//     const li = document.createElement('li');
//     const tekst = document.createTextNode(Element ${i});
//     li.appendChild(tekst);
//     lista.appendChild(li);
// }
//
"use strict";

// Czekamy, aż DOM będzie gotowy
document.addEventListener("DOMContentLoaded", function() {
    const lista = document.getElementById("lista-elementow");

    if (!lista) {
        return;
    }

    // 1. APPENDCHILD - dodawanie na koniec
    const el1 = document.createElement("li");
    el1.appendChild(document.createTextNode("Element 1"));
    lista.appendChild(el1);

    const el2 = document.createElement("li");
    el2.appendChild(document.createTextNode("Element 2"));
    lista.appendChild(el2);

    const el3 = document.createElement("li");
    el3.appendChild(document.createTextNode("Element 3 (zostanie zastąpiony)"));
    lista.appendChild(el3);

    // 2. INSERTBEFORE - wstawianie przed elementem
    const elNowy = document.createElement("li");
    elNowy.appendChild(document.createTextNode("Element wstawiony PRZED Element 2"));
    elNowy.style.color = "purple";
    lista.insertBefore(elNowy, el2);

    // 3. REPLACECHILD - zastępowanie elementu
    const elZast = document.createElement("li");
    elZast.appendChild(document.createTextNode("Element zastąpił Element 3"));
    elZast.style.color = "orange";
    lista.replaceChild(elZast, el3);

    // 4. PARENTNODE - dostęp do rodzica
    const el4 = document.createElement("li");
    el4.appendChild(document.createTextNode("Element 4 (rodzic to: " + lista.tagName + ")"));
    lista.appendChild(el4);

    // 5. REMOVECHILD - usuwanie elementu
    const el5 = document.createElement("li");
    el5.id = "do-usuniecia";
    el5.appendChild(document.createTextNode("Element 5 - kliknij przycisk by usunąć"));
    lista.appendChild(el5);

    // Przycisk do usuwania
    const btn = document.createElement("button");
    btn.textContent = "Usuń Element 5";
    btn.className = "btn btn-orange";
    btn.style.marginTop = "10px";

    btn.onclick = function() {
        const element = document.getElementById("do-usuniecia");
        if (element && element.parentNode) {
            element.parentNode.removeChild(element);  // REMOVECHILD!
            btn.disabled = true;
            btn.textContent = "✓ Usunięto!";
        }
    };

    // Dodaj przycisk pod listą
    lista.parentNode.appendChild(btn);
});