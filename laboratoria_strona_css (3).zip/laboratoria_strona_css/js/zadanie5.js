"use strict";

// Pobranie wszystkich formularzy na stronie
const forms = document.querySelectorAll('form');

forms.forEach(form => {
    // Focus i blur – wyświetlanie tekstów pomocy
    const inputs = form.querySelectorAll('input:not([type="submit"]):not([type="reset"]), textarea, select');

    inputs.forEach(input => {
        // Znajdź element <small> będący tekstem pomocy
        const helpText = input.parentElement.querySelector('small');

        input.addEventListener('focus', () => {
            if (helpText) {
                helpText.style.fontWeight = 'bold';
                helpText.style.color = '#0066cc';
            }
        });

        input.addEventListener('blur', () => {
            if (helpText) {
                helpText.style.fontWeight = 'normal';
                helpText.style.color = '#666';
            }
        });
    });

    // Submit – okno potwierdzające
    form.addEventListener('submit', e => {
        if (!confirm("Czy na pewno chcesz wysłać formularz?")) {
            e.preventDefault();
        }
    });

    // Reset – okno potwierdzające
    form.addEventListener('reset', e => {
        if (!confirm("Czy na pewno chcesz wyczyścić wszystkie pola formularza?")) {
            e.preventDefault();
        }
    });
});