"use strict";

const map = document.getElementById("event-map");
const info = document.getElementById("event-info");

// Flaga śledząca, czy mysz jest nad mapą
let isOverMap = false;

// === MOUSE OVER ===
map.addEventListener("mouseover", () => {
    isOverMap = true;
    info.style.color = "green";
    info.style.fontWeight = "bold";
});

// === MOUSE OUT ===
map.addEventListener("mouseout", () => {
    isOverMap = false;
    info.style.color = "red";
    info.style.fontWeight = "bold";
    info.textContent = "Zjechałeś z mapy!";
});

// === MOUSE MOVE ===
map.addEventListener("mousemove", e => {
    // Tylko jeśli mysz jest nad mapą, pokazuj współrzędne
    if (isOverMap) {
        info.style.color = "green";
        info.textContent =
            `Wjechałeś na mapę! | ` +
            `clientX: ${e.clientX}, clientY: ${e.clientY} | ` +
            `screenX: ${e.screenX}, screenY: ${e.screenY}`;
    }
});

// === MOUSE DOWN ===
map.addEventListener("mousedown", e => {
    alert(`Kliknięto na mapie!
ctrlKey: ${e.ctrlKey}
altKey: ${e.altKey}
shiftKey: ${e.shiftKey}`);
});

// === KEYDOWN dla demonstracji keyCode ===
document.addEventListener("keydown", e => {
    const keyInfo = `
Naciśnięty klawisz: ${e.key}
keyCode: ${e.keyCode}
ctrlKey: ${e.ctrlKey}
altKey: ${e.altKey}
shiftKey: ${e.shiftKey}`;

    info.textContent = keyInfo;
    info.style.color = "blue";
    info.style.fontWeight = "normal";
});