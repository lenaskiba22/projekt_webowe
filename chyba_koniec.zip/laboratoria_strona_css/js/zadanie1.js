// "use strict";
//
// const lista = document.getElementById('lista-elementow');
//
// for(let i = 1; i <= 3; i++){
//     const li = document.createElement('li');
//     const tekst = document.createTextNode(Element ${i});
//     li.appendChild(tekst);
//     lista.appendChild(li);
// }
//
"use strict";

let unikalneLicznik = 0;

function inicjujListe() {
    const lista = document.getElementById("lista-elementow");
    const info = document.getElementById("info-lista");

    if (!lista) {
        return;
    }

    function pokazInfo(tekst, kolor = "#0066cc") {
        info.style.display = "block";
        info.style.color = kolor;
        info.style.fontWeight = "bold";
        info.textContent = tekst;

        setTimeout(() => {
            info.style.display = "none";
        }, 3000);
    }

    // PRZYCISK: Dodaj element (appendChild)
    document.getElementById("btn-dodaj-element").addEventListener("click", function() {
        unikalneLicznik++;

        const nowyElement = document.createElement("li");
        const tekst = document.createTextNode("Element #" + unikalneLicznik + " (appendChild)");
        nowyElement.appendChild(tekst);
        nowyElement.setAttribute("data-id", unikalneLicznik);

        lista.appendChild(nowyElement);
        pokazInfo("✓ Dodano element #" + unikalneLicznik + " na koniec (appendChild). Łącznie: " + lista.children.length, "green");
    });

    // PRZYCISK: Wstaw przed pierwszym (insertBefore)
    document.getElementById("btn-wstaw-element").addEventListener("click", function() {
        if (lista.children.length === 0) {
            pokazInfo(" Lista jest pusta! Najpierw dodaj element.", "orange");
            return;
        }

        unikalneLicznik++;

        const nowyElement = document.createElement("li");
        const tekst = document.createTextNode("Element #" + unikalneLicznik + " (insertBefore)");
        nowyElement.appendChild(tekst);
        nowyElement.setAttribute("data-id", unikalneLicznik);

        lista.insertBefore(nowyElement, lista.children[0]);
        pokazInfo("✓ Wstawiono element #" + unikalneLicznik + " PRZED pierwszym (insertBefore). Łącznie: " + lista.children.length, "blue");
    });

    // PRZYCISK: Zastąp ostatni (replaceChild)
    document.getElementById("btn-zastap-element").addEventListener("click", function() {
        if (lista.children.length === 0) {
            pokazInfo("Lista jest pusta!", "orange");
            return;
        }

        unikalneLicznik++;

        const ostatni = lista.children[lista.children.length - 1];
        const staryId = ostatni.getAttribute("data-id");

        const nowyElement = document.createElement("li");
        const tekst = document.createTextNode("Element #" + unikalneLicznik + " (zastąpił #" + staryId + " - replaceChild)");
        nowyElement.appendChild(tekst);
        nowyElement.setAttribute("data-id", unikalneLicznik);

        lista.replaceChild(nowyElement, ostatni);
        pokazInfo("✓ Zastąpiono element #" + staryId + " → #" + unikalneLicznik + " (replaceChild)", "orange");
    });

    // PRZYCISK: Usuń pierwszy (removeChild)
    document.getElementById("btn-usun-element").addEventListener("click", function() {
        if (lista.children.length === 0) {
            pokazInfo(" Lista jest pusta!", "orange");
            return;
        }

        const pierwszy = lista.children[0];
        const id = pierwszy.getAttribute("data-id");
        lista.removeChild(pierwszy);

        pokazInfo("✓ Usunięto element #" + id + " (removeChild). Pozostało: " + lista.children.length, "red");
    });

    // PRZYCISK: Pokaż rodzica (parentNode)
    document.getElementById("btn-pokaz-rodzica").addEventListener("click", function() {
        const rodzic = lista.parentNode;
        pokazInfo("Rodzic listy (parentNode): <" + rodzic.tagName + "> id=\"" + (rodzic.id || "brak") + "\". Elementów na liście: " + lista.children.length, "purple");
    });

    // PRZYCISK: Reset
    document.getElementById("btn-reset").addEventListener("click", function() {
        if (confirm("Czy na pewno wyczyścić całą listę?")) {
            lista.innerHTML = "";
            pokazInfo("Lista wyczyszczona!", "gray");
        }
    });

    // Początkowe elementy - demonstracja wszystkich metod
    // 1. appendChild
    unikalneLicznik++;
    const el1 = document.createElement("li");
    el1.appendChild(document.createTextNode("Początkowy element #" + unikalneLicznik + " (appendChild)"));
    el1.setAttribute("data-id", unikalneLicznik);
    lista.appendChild(el1);

    // 2. appendChild
    unikalneLicznik++;
    const el2 = document.createElement("li");
    el2.appendChild(document.createTextNode("Początkowy element #" + unikalneLicznik + " (appendChild)"));
    el2.setAttribute("data-id", unikalneLicznik);
    lista.appendChild(el2);

    // 3. appendChild - zostanie zastąpiony
    unikalneLicznik++;
    const el3 = document.createElement("li");
    el3.appendChild(document.createTextNode("Początkowy element #" + unikalneLicznik));
    el3.setAttribute("data-id", unikalneLicznik);
    lista.appendChild(el3);

    // 4. insertBefore - wstaw przed el2
    unikalneLicznik++;
    const elInsert = document.createElement("li");
    elInsert.appendChild(document.createTextNode("Element #" + unikalneLicznik + " (insertBefore - wstawiony przed #2)"));
    elInsert.setAttribute("data-id", unikalneLicznik);
    elInsert.style.color = "purple";
    lista.insertBefore(elInsert, el2);

    // 5. replaceChild - zastąp el3
    unikalneLicznik++;
    const elReplace = document.createElement("li");
    elReplace.appendChild(document.createTextNode("Element #" + unikalneLicznik + " (replaceChild - zastąpił #3)"));
    elReplace.setAttribute("data-id", unikalneLicznik);
    elReplace.style.color = "orange";
    lista.replaceChild(elReplace, el3);

    // 6. parentNode - pokaż rodzica
    const rodzic = lista.parentNode;
    pokazInfo("📋 Lista zainicjowana. Rodzic (parentNode): <" + rodzic.tagName + ">. Elementów: " + lista.children.length, "#0066cc");
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", inicjujListe);
} else {
    inicjujListe();
}