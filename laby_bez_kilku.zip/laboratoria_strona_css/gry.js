function zgadywankaMiesiac() {
    const miesiace = [
        "styczeń", "luty", "marzec", "kwiecień", "maj", "czerwiec",
        "lipiec", "sierpień", "wrzesień", "październik", "listopad", "grudzień"
    ];
    let losowyIndeks = Math.floor(Math.random() * miesiace.length);
    let losowyMiesiac = miesiace[losowyIndeks];
    let szanse = 3;

    while (szanse > 0) {
        let odpowiedz = window.prompt("zgadnij miesiąc, masz " + szanse + " szansy(a).");
        if (odpowiedz.toLowerCase() === losowyMiesiac) {
            window.alert("zgadłeś");
            return;
        } else {
            szanse--;
            window.alert("spróbuj ponownie, zostało szans: " + szanse);
        }
    }

    window.alert("nie udało ci się, prawidłowa odpowiedź to: " + losowyMiesiac);
}


const zgadywankaLiczba = () => {
    const losowaLiczba = Math.floor(Math.random() * 100) + 1;
    let szanse = 3;

    while (szanse > 0) {
        let odpowiedz = parseInt(window.prompt("zgadnij liczbę, masz " + szanse + " szansy(a)."));
        if (odpowiedz === losowaLiczba) {
            window.alert("zgadłeś");
            return;
        }
        if (odpowiedz < losowaLiczba) {
            window.alert("spróbuj większą liczbę");
        }
        if (odpowiedz > losowaLiczba) {
            window.alert("spróbuj mniejszą liczbę");
        }
        szanse--;
    }

    window.alert("nie udało się, prawidłowa liczba to: " + losowaLiczba);
}


function zgadywankaLiczbaN() {
    const losowaLiczba = Math.floor(Math.random() * 100) + 1;
    let szanse = parseInt(window.prompt("ile prób chcesz mieć?"));

    // walidacja ilosci prob
    if (isNaN(szanse)) {
        window.alert("Podaj prawidłową liczbę prób");
        return;
    }
    if (szanse <= 0) {
        window.alert("Podaj prawidłową liczbę prób");
        return;
    }

    while (szanse > 0) {
        let odpowiedz = parseInt(window.prompt("zgadnij liczbę, masz " + szanse + " szansy(a)."));
        if (odpowiedz === losowaLiczba) {
            window.alert("zgadłeś");
            return;
        }
        if (odpowiedz < losowaLiczba) {
            window.alert("spróbuj większą liczbę");
        }
        if (odpowiedz > losowaLiczba) {
            window.alert("spróbuj mniejszą liczbę");
        }
        szanse--;
    }

    window.alert("nie udało się, prawidłowa liczba to: " + losowaLiczba);
}


const sumaLiczb = () => {
    const n = parseInt(window.prompt("ile liczb chcesz podać?"));
    let suma = 0;

    for (let i = 1; i <= n; i++) {
        let liczba = parseInt(window.prompt("podaj liczbę nr " + i + ":"));
        suma += liczba;
        window.alert("suma dotychczas podanych liczb: " + suma);
    }

    window.alert("końcowa suma: " + suma);
}

function startGame(game) {
    if (game === 'zgadywankaMiesiac') {
        zgadywankaMiesiac();
    }
    if (game === 'zgadywankaLiczba') {
        zgadywankaLiczba();
    }
    if (game === 'zgadywankaLiczbaN') {
        zgadywankaLiczbaN();
    }
    if (game === 'sumaLiczb') {
        sumaLiczb();
    }
    if (game !== 'zgadywankaMiesiac' && game !== 'zgadywankaLiczba' && game !== 'zgadywankaLiczbaN' && game !== 'sumaLiczb') {
        window.alert('Nieznana gra!');
    }
}