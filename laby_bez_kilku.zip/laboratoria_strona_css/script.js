let licznikOdwiedzin = 0;
let ocenaStrony = 0;

// funkcja 1
function powitanieUzytkownika() {
    let imie = window.prompt("Jak masz na imię?");

    if (imie !== null && imie.trim() !== "") {
        licznikOdwiedzin++;
        window.alert("Witaj " + imie + " To Twoja wizyta nr " + licznikOdwiedzin + " na stronie.");

        let powitanieDiv = document.getElementById("powitanie");
        if (powitanieDiv) {
            let tempDiv = document.createElement('div');
            tempDiv.style.display = 'none';
            document.body.appendChild(tempDiv);

            let originalWrite = document.write;
            let content = '';

            document.write = document.writeln = function(text) {
                content += text + '\n';
            };

            document.writeln("<p>");
            document.writeln("Witaj <strong>" + imie + "</strong> Miło Cię gościć na stronie o Wrocławiu.");
            document.writeln("</p>");

            document.write = originalWrite;

            powitanieDiv.innerHTML = content;
            document.body.removeChild(tempDiv);
        }
    } else {
        window.alert("Nie podałeś imienia.");
    }
}

// funkcja 2
const kalkulatorBudzetu = () => {
    let dni = window.prompt("Na ile dni planujesz wyjazd do Wrocławia?");
    dni = parseInt(dni);

    if (isNaN(dni)) {
        window.alert("Proszę podać prawidłową liczbę dni.");
        return;
    }
    if (dni <= 0) {
        window.alert("Proszę podać prawidłową liczbę dni.");
        return;
    }

    let osoby = window.prompt("Ile osób będzie uczestniczyć?");
    osoby = parseInt(osoby);

    if (isNaN(osoby)) {
        window.alert("Proszę podać prawidłową liczbę osób.");
        return;
    }
    if (osoby <= 0) {
        window.alert("Proszę podać prawidłową liczbę osób.");
        return;
    }

    let kosztDziennie = 150;
    let wynik = document.getElementById("wynik-budzetu");

    let calkowitKoszt = 0;
    let dzienCounter = 0;
    while (dzienCounter < dni) {
        calkowitKoszt += kosztDziennie * osoby;
        dzienCounter++;
    }

    let kategoria;
    switch (true) {
        case (calkowitKoszt < 500):
            kategoria = "Budżetowa";
            break;
        case (calkowitKoszt < 1500):
            kategoria = "Standardowa";
            break;
        case (calkowitKoszt < 3000):
            kategoria = "Komfortowa";
            break;
        default:
            kategoria = "Premium";
    }

    wynik.innerHTML = `
        <div>
            <h4>Szacunkowy koszt wycieczki:</h4>
            <p><strong>${calkowitKoszt} PLN</strong></p>
            <p>Dni: ${dni} | Osób: ${osoby} | Kategoria: ${kategoria}</p>
        </div>
    `;
}


// funkcja 3
function licznikDniDoWycieczki() {
    let dataWycieczki = window.prompt("Podaj datę wycieczki do Wrocławia (w formacie DD.MM.RRRR):");

    let wzorzec = /^(0[1-9]|[12][0-9]|3[01])\.(0[1-9]|1[0-2])\.(\d{4})$/;
    let dopasowanie = dataWycieczki ? dataWycieczki.match(wzorzec) : null;

    if (!dopasowanie) {
        window.alert("Podaj datę w prawidłowym formacie DD.MM.RRRR");
        return;
    }

    let dzien = parseInt(dopasowanie[1]);
    let miesiac = parseInt(dopasowanie[2]) - 1;
    let rok = parseInt(dopasowanie[3]);

    // sprawdzanie czy dzień jest ok dla miesiąca
    const daysInMonth = new Date(rok, miesiac + 1, 0).getDate();
    if (dzien > daysInMonth) {
        window.alert("Podany dzień jest niepoprawny dla wybranego miesiąca.");
        return;
    }

    let teraz = new Date();
    let dataDocelowa = new Date(rok, miesiac, dzien);

    let dniPozostalo = Math.ceil((dataDocelowa - teraz) / 86400000);

    let wynikDiv = document.getElementById("wynik-licznika");

    let tekst = "<div>";
    tekst += "<h4>Odliczanie do wycieczki</h4>";

    if (dniPozostalo < 0) {
        tekst += `<p>Ta data już minęła.</p>`;
    }
    if (dniPozostalo >= 0 && dniPozostalo == 0) {
        tekst += `<p><strong>Dziś jest dzień wycieczki.</strong></p>`;
    }
    if (dniPozostalo > 0) {
        tekst += `<p>Do wycieczki pozostało <strong>${dniPozostalo}</strong> `;
        if(dniPozostalo === 1) {
            tekst += "dzień";
        } else {
            tekst += "dni";
        }
        tekst += ".</p>";
        tekst += `<p>Data wycieczki: <strong>${dataWycieczki}</strong></p>`;
    }

    tekst += "</div>";

    wynikDiv.innerHTML = tekst;
}




// funkcja 4
function losowyFakt() {
    let fakty = [
        "Wrocław ma ponad 100 mostów.",
        "W mieście znajduje się ponad 400 krasnali.",
        "Wrocław był Europejską Stolicą Kultury w 2016 roku.",
        "Hala Stulecia jest na liście UNESCO.",
        "We Wrocławiu działa najstarszy ogród zoologiczny w Polsce."
    ];


    let losowyIndeks = Math.floor(Math.random() * fakty.length);
    let fakt = fakty[losowyIndeks];

    let faktDiv = document.getElementById("losowy-fakt");

    faktDiv.innerHTML = "<p style='color: #999;'>Losuję fakt</p>";

    let i = 0;
    let tekst = "Losuję fakt";
    do {
        tekst += ".";
        i++;
    } while (i < 3);

    setTimeout(() => {
        faktDiv.innerHTML = `
            <div>
                <h4>Ciekawy fakt o Wrocławiu:</h4>
                <p><strong>${fakt}</strong></p>
            </div>
        `;
    }, 500);
}

// funkcja 5
const ocenStrone = () => {
    let ocena = window.prompt("Oceń naszą stronę w skali od 1.0 do 5.0 (np. 4.5):");
    ocena = parseFloat(ocena);

    if (isNaN(ocena)) {
        window.alert("Proszę podać prawidłową ocenę od 1.0 do 5.0");
        return;
    }
    if (ocena < 1) {
        window.alert("Proszę podać prawidłową ocenę od 1.0 do 5.0");
        return;
    }
    if (ocena > 5) {
        window.alert("Proszę podać prawidłową ocenę od 1.0 do 5.0");
        return;
    }

    ocenaStrony = ocena;
    let ocenaDiv = document.getElementById("ocena");

    // komentarze w zaleznosci od oceny - działa
    let komentarz;
    if (ocena >= 4.5) {
        komentarz = "Dziękujemy za tak wysoką ocenę";
    }
    if (ocena < 4.5 && ocena >= 3.5) {
        komentarz = "Cieszymy się, że Ci się podoba";
    }
    if (ocena < 3.5 && ocena >= 2.5) {
        komentarz = "Będziemy się bardziej starać";
    }
    if (ocena < 2.5) {
        komentarz = "Przykro nam. Co możemy poprawić?";
    }

    ocenaDiv.innerHTML = `
        <div>
            <h4>Twoja ocena: ${ocena.toFixed(1)}/5.0</h4>
            <p>${komentarz}</p>
        </div>
    `;

    window.alert("Dziękujemy za ocenę: " + ocena.toFixed(1) + "/5.0");
}


window.addEventListener('load', function() {
    console.log("Strona o Wrocławiu załadowana!");

    setTimeout(powitanieUzytkownika, 500);
});


document.addEventListener('DOMContentLoaded', function() {
    let btnBudzet = document.getElementById("btn-budzet");
    let btnLicznik = document.getElementById("btn-licznik");
    let btnFakt = document.getElementById("btn-fakt");
    let btnOcena = document.getElementById("btn-ocena");

    if (btnBudzet) {
        btnBudzet.addEventListener('click', kalkulatorBudzetu);
    }

    if (btnLicznik) {
        btnLicznik.addEventListener('click', licznikDniDoWycieczki);
    }

    if (btnFakt) {
        btnFakt.addEventListener('click', losowyFakt);
    }

    if (btnOcena) {
        btnOcena.addEventListener('click', ocenStrone);
    }

});