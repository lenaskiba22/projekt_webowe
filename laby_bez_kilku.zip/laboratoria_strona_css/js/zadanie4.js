"use strict";

const map = document.getElementById("event-map");
const info = document.getElementById("event-info");

// === MOUSE MOVE ===
map.addEventListener("mousemove", e => {
    info.textContent =
        `clientX: ${e.clientX}, clientY: ${e.clientY} | ` +
        `screenX: ${e.screenX}, screenY: ${e.screenY}`;
});

// === MOUSE DOWN ===
map.addEventListener("mousedown", e => {
    alert(`Kliknięto na mapie!
ctrlKey: ${e.ctrlKey}
altKey: ${e.altKey}
shiftKey: ${e.shiftKey}`);
});

// === MOUSE OVER ===
map.addEventListener("mouseover", () => {
    info.style.color = "green";
    info.textContent = "Wjechałeś na mapę!";
});

// === MOUSE OUT ===
map.addEventListener("mouseout", () => {
    info.style.color = "black";
    info.textContent = "Zjechałeś z mapy!";
});
