"use strict";

document.getElementById('images-count').textContent = `Liczba obrazów: ${document.images.length}`;
document.getElementById('links-count').textContent = `Liczba linków: ${document.links.length}`;
document.getElementById('forms-count').textContent = `Liczba formularzy: ${document.forms.length}`;

