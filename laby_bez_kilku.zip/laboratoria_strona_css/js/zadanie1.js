"use strict";

const lista = document.getElementById('lista-elementow');

for(let i = 1; i <= 3; i++){
    const li = document.createElement('li');
    const tekst = document.createTextNode(`Element ${i}`);
    li.appendChild(tekst);
    lista.appendChild(li);
}
