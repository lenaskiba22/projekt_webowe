"use strict";

// Pobranie formularza ze strony kontakt
const form = document.querySelector('form');

if (form) {
    // Focus i blur – wyświetlanie tekstów pomocy obok inputów
    const inputs = form.querySelectorAll('input, textarea');
    inputs.forEach(input => {
        const info = input.closest('.form-row')?.querySelector('.form-info');
        input.addEventListener('focus', () => {
            if(info) info.style.display = 'block';
        });
        input.addEventListener('blur', () => {
            if(info) info.style.display = 'none';
        });
    });

    // Submit i reset – okna potwierdzające
    form.addEventListener('submit', e => {
        if (!confirm("Na pewno wysłać formularz?")) e.preventDefault();
    });

    form.addEventListener('reset', e => {
        if (!confirm("Na pewno wyczyścić formularz?")) e.preventDefault();
    });
}
